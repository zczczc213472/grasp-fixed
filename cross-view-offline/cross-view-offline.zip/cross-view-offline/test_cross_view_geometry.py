"""Offline numerical, rejection, evidence and deliverable regression tests."""
import base64
import copy
import json
from pathlib import Path
import unittest
import zlib
import numpy as np
import cross_view_geometry as g

K = [100,0,50, 0,100,40, 0,0,1]
IDENTITY = [0,0,0,0,0,0,1]


def project(p, **kw):
    args = dict(model='pinhole',D=[],image_size=(100,80),calibration_size=(100,80))
    args.update(kw)
    return g.project_points(p,K,**args)


def depth_fixture(raw, scale=10000):
    raw=np.asarray(raw,dtype='<u2')
    return dict(encoding='zlib+base64/uint16le',data=base64.b64encode(zlib.compress(raw.tobytes())).decode(),w=raw.shape[1],h=raw.shape[0],depth_scale=scale)


class GeometryTests(unittest.TestCase):
    def test_actual_unit_scale_10000_and_missing(self):
        raw,z=g.decode_depth(depth_fixture([[10000,250,0,65535]]))
        np.testing.assert_allclose(z[0,[0,1,3]],[1,.025,6.5535])
        self.assertTrue(np.isnan(z[0,2]));self.assertEqual(raw.dtype,np.dtype('<u2'))

    def test_scale_is_configuration_not_constant(self):
        _,z=g.decode_depth(depth_fixture([[1000]],scale=2000))
        self.assertEqual(z[0,0],.5)

    def test_scale_required(self):
        e=depth_fixture([[1]]);del e['depth_scale']
        with self.assertRaises(KeyError):g.decode_depth(e)

    def test_bad_scales_rejected(self):
        for s in (0,-1,float('nan'),float('inf')):
            with self.subTest(scale=s),self.assertRaises(ValueError):g.decode_depth(depth_fixture([[1]],s))

    def test_payload_length_and_encoding_rejected(self):
        for field,value in [('w',2),('encoding','uint16be')]:
            e=depth_fixture([[1]]);e[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):g.decode_depth(e)

    def test_little_endian(self):
        raw,_=g.decode_depth(depth_fixture([[0x1234]]))
        self.assertEqual(int(raw[0,0]),4660)

    def test_quaternion_normalizes(self):
        q=[0,0,2,2]
        np.testing.assert_allclose(g.quaternion_rotation(q),[[0,-1,0],[1,0,0],[0,0,1]],atol=1e-14)
        np.testing.assert_allclose(g.quaternion_rotation(q),g.quaternion_rotation([-x for x in q]))

    def test_zero_and_nonfinite_quaternion_rejected(self):
        for q in ([0,0,0,0],[0,0,0,float('nan')],[0,0,0,float('inf')],[1,2,3]):
            with self.subTest(q=q),self.assertRaises(ValueError):g.quaternion_rotation(q)

    def test_extreme_finite_quaternion_normalization(self):
        np.testing.assert_allclose(g.quaternion_rotation([0,0,1e300,1e300]),g.quaternion_rotation([0,0,1,1]))

    def test_known_rotation_translation_and_inverse(self):
        pose=[1,2,3,0,0,1,1]
        actual=g.transform_points([[1,0,0],[0,1,0]],pose)
        np.testing.assert_allclose(actual,[[1,3,3],[0,2,3]],atol=1e-14)
        np.testing.assert_allclose(g.transform_points(actual,pose,inverse=True),[[1,0,0],[0,1,0]],atol=1e-14)

    def test_multidimensional_roundtrip(self):
        points=np.arange(18,dtype=float).reshape(2,3,3)/10
        pose=[.3,-.2,1.7,.2,-.4,.1,.8]
        np.testing.assert_allclose(g.transform_points(g.transform_points(points,pose),pose,inverse=True),points,atol=1e-14)

    def test_invalid_transform_inputs_rejected(self):
        for p,pose in [([1,2],IDENTITY),([1,2,3],[0]*6),([1,2,float('nan')],IDENTITY)]:
            with self.assertRaises(ValueError):g.transform_points(p,pose)

    def test_projection_front_center_and_off_axis(self):
        uv,valid,inside=project([[0,0,2],[.1,.2,1]])
        np.testing.assert_allclose(uv,[[50,40],[60,60]])
        self.assertTrue(valid.all());self.assertTrue(inside.all())

    def test_behind_and_on_camera_plane_rejected(self):
        uv,valid,inside=project([[0,0,-1],[0,0,0],[1,1,1]])
        self.assertTrue(np.isnan(uv[:2]).all());self.assertFalse(valid[:2].any());self.assertFalse(inside[:2].any())
        self.assertTrue(valid[2]);self.assertFalse(inside[2])

    def test_unknown_model_and_missing_explicit_model(self):
        with self.assertRaises(ValueError):project([0,0,1],model='shitong-fisheye')
        with self.assertRaises(TypeError):g.project_points([0,0,1],K,D=[],image_size=(100,80),calibration_size=(100,80))

    def test_size_mismatch_no_implicit_rescale(self):
        with self.assertRaises(ValueError):project([0,0,1],image_size=(50,40))

    def test_nonfinite_and_invalid_K(self):
        for k in ([0]*9,[float('nan')]*9,[-1,0,50,0,100,40,0,0,1]):
            with self.assertRaises(ValueError):g.project_points([0,0,1],k,model='pinhole',D=[],image_size=(100,80),calibration_size=(100,80))

    def test_model_coefficient_contract(self):
        for model,d in [('pinhole',[0]),('plumb_bob',[]),('equidistant',[0]*5)]:
            with self.subTest(model=model),self.assertRaises(ValueError):project([0,0,1],model=model,D=d)

    def test_plumb_bob_zero_equals_pinhole(self):
        np.testing.assert_allclose(project([.2,-.3,1],model='plumb_bob',D=[0]*5)[0],project([.2,-.3,1])[0])

    def test_plumb_bob_known_radial_and_tangential(self):
        uv,_,_=project([.2,.1,1],model='plumb_bob',D=[.1,0,.01,.02,0])
        # r2=.05; x'= .201+.0004+.0026=.204; y'=.1005+.0007+.0008=.102
        np.testing.assert_allclose(uv,[70.4,50.2],atol=1e-12)

    def test_equidistant_explicit_coefficients_and_optical_axis(self):
        uv,_,_=project([[0,0,1],[1,0,1]],model='equidistant',D=[0]*4)
        np.testing.assert_allclose(uv,[[50,40],[50+100*np.pi/4,40]],atol=1e-12)

    def test_unproject_requires_explicit_pinhole(self):
        with self.assertRaises(ValueError):g.unproject_depth(np.ones((2,2)),K,model='unknown')

    def test_unproject_project_roundtrip_with_missing(self):
        z=np.ones((80,100));z[0,0]=np.nan
        cloud=g.unproject_depth(z,K,model='pinhole')
        self.assertTrue(np.isnan(cloud[0,0]).all())
        uv,_,_=project(cloud[30,70]);np.testing.assert_allclose(uv,[70,30])

    def test_cross_view_chain_uses_inverse_head(self):
        mapped=g.cross_view_map([0,0,1],[1,0,0,0,0,0,1],[.5,0,0,0,0,0,1],K,model='pinhole',D=[],image_size=(100,80),calibration_size=(100,80))
        np.testing.assert_allclose(mapped['base_point'],[1,0,1]);np.testing.assert_allclose(mapped['head_pixel'],[100,40]);self.assertFalse(mapped['inside_image'])

    def test_rectification_rotation_validation(self):
        with self.assertRaises(ValueError):g.cross_view_map([0,0,1],IDENTITY,IDENTITY,K,model='pinhole',D=[],image_size=(100,80),calibration_size=(100,80),rectification=np.eye(3)*2)

    def test_rectification_known_rotation(self):
        mapped=g.cross_view_map([.1,0,1],IDENTITY,IDENTITY,K,model='pinhole',D=[],image_size=(100,80),calibration_size=(100,80),rectification=[[0,-1,0],[1,0,0],[0,0,1]])
        np.testing.assert_allclose(mapped['head_pixel'],[50,50],atol=1e-12)

    def test_unconfirmed_and_forged_confirmed_never_executable(self):
        for c in ({},{'identity_confirmed':False,'executable':True},{'identity_confirmed':True,'executable':True}):
            with self.assertRaises(ValueError):g.require_executable(c)


class RealEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=Path(__file__).resolve().parent
        cls.e=json.loads((cls.root/'inputs/right-scene-evidence.local.json').read_text(encoding='utf-8'))
        cls.a=json.loads((cls.root/'inputs/right-scene-analysis.local.json').read_text(encoding='utf-8'))
        cls.jpeg=(cls.root/'right-head-reference.local.jpg').read_bytes()
        cls.report=g.build_report(cls.e,cls.a,cls.jpeg)

    def test_real_scale_missing_and_image_binding(self):
        self.assertEqual(self.report['provenance']['depth_scale'],10000)
        self.assertEqual(self.report['depth_diagnostics']['valid_pixels'],594150)
        self.assertEqual(self.report['depth_diagnostics']['missing_pixels'],327450)
        self.assertTrue(self.report['provenance']['jpeg_matches_embedded_bytes'])
        self.assertEqual(self.report['model_evidence']['jpeg_size'],[1280,960])

    def test_every_original_candidate_retained_without_identity_promotion(self):
        self.assertEqual(self.report['candidate_count'],35)
        for i,c in enumerate(self.report['candidates']):
            self.assertEqual(c['candidate_id'],i);self.assertEqual(c['original_candidate'],self.a['cube_25mm_candidates'][i])
            self.assertIs(c['identity_confirmed'],False);self.assertIs(c['executable'],False)
            self.assertIn('IDENTITY_UNCONFIRMED',c['blockers'])

    def test_source_metadata_not_promoted_to_calibration_proof(self):
        meta=self.report['model_evidence']
        self.assertIs(meta['model_determined'],False);self.assertIsNone(meta['confirmed_model'])
        self.assertEqual(meta['third_rgb_argument'],'once');self.assertIs(meta['automatic_model_selection'],False)
        e=copy.deepcopy(self.e);e['head_reference']['sdk_intrinsic']['camera_type']='unknown-sensor'
        other=g.metadata_evidence(e,(1280,960));self.assertIs(other['model_determined'],False)
        self.assertFalse(g.metadata_evidence(e,(640,480))['image_size_matches'])

    def test_unknown_and_mismatched_metadata_reported(self):
        e=copy.deepcopy(self.e)
        e['head_reference']['sdk_intrinsic']['distortion_model']='unknown'
        self.assertTrue(any('UNKNOWN_DECLARED_MODEL' in s for s in g.metadata_evidence(e,(1280,960))['conflicts']))
        e['head_reference']['sdk_intrinsic']['distortion_model']='equidistant'
        self.assertTrue(any('MODEL_COEFFICIENT_MISMATCH' in s for s in g.metadata_evidence(e,(1280,960))['conflicts']))

    def test_empty_real_depth_cannot_manufacture_candidates(self):
        e=copy.deepcopy(self.e)
        e['data']=base64.b64encode(zlib.compress(bytes(e['w']*e['h']*2))).decode()
        with self.assertRaisesRegex(ValueError,'no measured depth'):g.build_report(e,self.a,self.jpeg)

    def test_real_image_dimension_mismatch_rejected(self):
        e=copy.deepcopy(self.e);e['head_reference']['sdk_intrinsic']['width']=640
        with self.assertRaises(ValueError):g.build_report(e,self.a,self.jpeg)

    def test_report_strict_json_and_non_executable(self):
        json.dumps(self.report,allow_nan=False)
        self.assertFalse(self.report['identity_confirmed']);self.assertFalse(self.report['executable'])
        self.assertIsNone(self.report['projection_diagnostics']['measured_reprojection_error_px'])

    def test_cluster_summary_not_converted_to_measured_sample(self):
        self.assertGreater(self.report['candidates'][5]['nearest_measured_distance_mm'],10)
        for i in (19,29,30):self.assertIsNone(self.report['candidates'][i]['wrist_center_depth_m'])
        self.assertAlmostEqual(self.report['candidates'][0]['height_above_surface_mm'],23.524198303234156)

    def test_saved_report_reproduces_computation(self):
        saved=json.loads((self.root/'projection-report.json').read_text(encoding='utf-8'))
        self.assertEqual(saved['candidates'],self.report['candidates'])
        self.assertEqual(saved['projection_diagnostics'],self.report['projection_diagnostics'])

    def test_html_embedded_data_matches_json_and_no_remote_resources(self):
        html=(self.root/'review.html').read_text(encoding='utf-8')
        start='<script id="report-data" type="application/json">'
        embedded=json.loads(html.split(start)[1].split('</script>')[0])
        self.assertEqual(embedded['candidates'],self.report['candidates'])
        self.assertNotIn('__REPORT_JSON__',html)
        self.assertNotIn('https://',html);self.assertNotIn('http://',html)
        self.assertNotIn('fetch(',html)
        self.assertIn("connect-src 'none'",html)
        self.assertIn('诊断假设，未完成校准',html)

if __name__=='__main__':unittest.main(verbosity=2)
