"""Regression tests for numerical edge cases and portable delivery integrity."""
import base64
import copy
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
import zlib
import numpy as np
from PIL import Image
import cross_view_geometry as g
from package_delivery import build_archive, create_manifest, delivery_files, verify_archive

ROOT=Path(__file__).resolve().parent


class DepthBoundaryTests(unittest.TestCase):
    def test_right_bottom_pixel_rounding_never_indexes_past_image(self):
        depth=np.array([[1.,2.],[3.,4.]])
        self.assertIsNone(g.sample_depth_at_pixel(depth,[1.75,1]))
        self.assertIsNone(g.sample_depth_at_pixel(depth,[1,1.75]))
        self.assertEqual(g.sample_depth_at_pixel(depth,[1.4,1.4]),4.)

    def test_missing_outside_and_behind_pixels_not_filled(self):
        depth=np.array([[np.nan,2.],[3.,0.]])
        for pixel in ([0,0],[1,1],[-.1,0],[2,0],[float('nan'),1]):
            with self.subTest(pixel=pixel):self.assertIsNone(g.sample_depth_at_pixel(depth,pixel))

    def test_depth_preview_preserves_missing_and_does_not_modify_depth(self):
        z=np.array([[np.nan,.1],[.55,6.]])
        before=z.copy()
        image=np.asarray(Image.open(io.BytesIO(g.depth_preview_png(z))))
        np.testing.assert_array_equal(image[0,0],[0,0,0])
        np.testing.assert_array_equal(image[0,1],[0,255,80])
        np.testing.assert_array_equal(image[1,1],[255,0,80])
        np.testing.assert_allclose(z,before,equal_nan=True)

    def test_depth_preview_invalid_range_rejected(self):
        for near,far in [(1,1),(2,1),(float('nan'),1)]:
            with self.assertRaises(ValueError):g.depth_preview_png(np.ones((2,2)),near,far)

    def test_trailing_and_truncated_compressed_depth_rejected(self):
        raw=np.array([[10000]],dtype='<u2').tobytes()
        for packed in [zlib.compress(raw)+b'extra',zlib.compress(raw)[:-1]]:
            e={'encoding':'zlib+base64/uint16le','depth_scale':10000,'w':1,'h':1,'data':base64.b64encode(packed).decode()}
            with self.assertRaises(ValueError):g.decode_depth(e)

    def test_boolean_scale_and_dimensions_rejected(self):
        e={'encoding':'zlib+base64/uint16le','depth_scale':True,'w':1,'h':1,'data':base64.b64encode(zlib.compress(b'\x01\x00')).decode()}
        with self.assertRaises(ValueError):g.decode_depth(e)
        e.update(depth_scale=10000,w=True)
        with self.assertRaises(ValueError):g.decode_depth(e)
        for dimensions in [(True,80),(100,float('nan')),(100,0)]:
            with self.assertRaises(ValueError):g.validate_camera('pinhole',[100,0,50,0,100,40,0,0,1],[],dimensions,dimensions)


class RealGeometryRejectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e=json.loads((ROOT/'inputs/right-scene-evidence.local.json').read_text(encoding='utf-8'))
        cls.a=json.loads((ROOT/'inputs/right-scene-analysis.local.json').read_text(encoding='utf-8'))
        cls.jpeg=(ROOT/'right-head-reference.local.jpg').read_bytes()
        cls.report=g.build_report(cls.e,cls.a,cls.jpeg)

    def test_unknown_declared_model_rejected_in_actual_report_builder(self):
        e=copy.deepcopy(self.e);e['head_reference']['sdk_intrinsic']['distortion_model']='unknown'
        with self.assertRaisesRegex(ValueError,'unknown model'):g.build_report(e,self.a,self.jpeg)

    def test_declared_coefficient_mismatch_rejected(self):
        e=copy.deepcopy(self.e);e['head_reference']['sdk_intrinsic']['D']=[0]*4
        with self.assertRaisesRegex(ValueError,'coefficient mismatch'):g.build_report(e,self.a,self.jpeg)

    def test_same_size_wrong_photo_rejected(self):
        image=Image.new('RGB',(1280,960));buffer=io.BytesIO();image.save(buffer,format='JPEG')
        with self.assertRaisesRegex(ValueError,'image binding unverified'):g.build_report(self.e,self.a,buffer.getvalue())

    def test_projection_translation_not_silently_dropped(self):
        e=copy.deepcopy(self.e);e['head_reference']['sdk_intrinsic']['P'][3]=.01
        with self.assertRaisesRegex(ValueError,'nonzero P translation'):g.build_report(e,self.a,self.jpeg)

    def test_reflection_is_not_a_rectification_rotation(self):
        e=copy.deepcopy(self.e);e['head_reference']['sdk_intrinsic']['R']=[-1,0,0,0,1,0,0,0,1]
        with self.assertRaisesRegex(ValueError,'rectification rotation'):g.build_report(e,self.a,self.jpeg)

    def test_empty_candidates_preserved_as_empty_with_no_fabricated_visual_review(self):
        a=copy.deepcopy(self.a);a['cube_25mm_candidates']=[];a['candidate_count']=0
        r=g.build_report(self.e,a,self.jpeg)
        self.assertEqual(r['candidates'],[]);self.assertEqual(r['candidate_count'],0)
        self.assertIsNone(r['projection_diagnostics']['H0_to_H1_pixel_shift_min_median_max'])
        self.assertEqual(r['projection_diagnostics']['visual_review'],[])
        self.assertIsNone(r['projection_diagnostics']['apparent_misalignment_observed'])
        json.dumps(r,allow_nan=False)

    def test_count_mismatch_rejected(self):
        a=copy.deepcopy(self.a);a['candidate_count']=34
        with self.assertRaisesRegex(ValueError,'candidate count'):g.build_report(self.e,a,self.jpeg)

    def test_nonfinite_surface_and_negative_dimensions_rejected(self):
        a=copy.deepcopy(self.a);a['surface_candidate_z_m']=float('nan')
        with self.assertRaisesRegex(ValueError,'surface hypothesis'):g.build_report(self.e,a,self.jpeg)
        a=copy.deepcopy(self.a);a['cube_25mm_candidates'][0]['observed_extent_m'][0]=-.01
        with self.assertRaisesRegex(ValueError,'negative observed extent'):g.build_report(self.e,a,self.jpeg)

    def test_nearest_measured_points_trace_to_actual_raw_depth_pixels(self):
        raw,depth=g.decode_depth(self.e)
        cloud=g.unproject_depth(depth,self.e['K'],model='pinhole')
        for c in self.report['candidates']:
            x,y=c['nearest_measured_wrist_pixel']
            self.assertGreater(raw[y,x],0)
            self.assertEqual(c['nearest_measured_raw_depth'],int(raw[y,x]))
            measured=g.transform_points(cloud[y,x],self.e['camera_to_base_xyzw'])
            np.testing.assert_allclose(measured,c['nearest_measured_base_point'],atol=1e-12)
            self.assertAlmostEqual(raw[y,x]/self.e['depth_scale'],depth[y,x])

    def test_saved_depth_preview_has_exactly_the_original_missing_pixels(self):
        raw,_=g.decode_depth(self.e)
        pixels=np.asarray(Image.open(ROOT/'depth-preview.png'))
        self.assertEqual(pixels.shape,(720,1280,3))
        np.testing.assert_array_equal(np.all(pixels==0,axis=-1),raw==0)
        self.assertEqual(int(np.all(pixels==0,axis=-1).sum()),327450)

    def test_camera_label_does_not_assert_a_different_sensor_as_fact(self):
        e=copy.deepcopy(self.e);e['head_reference']['sdk_intrinsic']['camera_type']='unknown-sensor'
        meta=g.metadata_evidence(e,(1280,960))
        self.assertFalse(any('camera_type=shitong-fisheye' in text for text in meta['conflicts']))
        self.assertFalse(meta['model_determined'])


class DeliveryIntegrityTests(unittest.TestCase):
    def setUp(self):
        (ROOT/'work').mkdir(exist_ok=True)
        self.directory=tempfile.TemporaryDirectory(dir=ROOT/'work')
        self.addCleanup(self.directory.cleanup)
        self.root=Path(self.directory.name)
        (self.root/'REPORT.md').write_text('离线诊断\n',encoding='utf-8')
        (self.root/'result.json').write_text('{"executable":false}',encoding='utf-8')

    def test_delivery_excludes_runtime_hosting_hidden_and_symlink_files(self):
        for name in ['download-site/dist/private.json','work/debug.json','.env','__pycache__/old.py']:
            path=self.root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('placeholder',encoding='utf-8')
        (self.root/'linked.json').symlink_to(self.root/'result.json')
        self.assertEqual({p.name for p in delivery_files(self.root)},{'REPORT.md','result.json'})

    def test_archive_manifest_matches_every_payload_and_has_one_root(self):
        result=build_archive(self.root)
        self.assertTrue(result['verified']);self.assertEqual(result['file_count'],3)
        self.assertEqual(hashlib.sha256(Path(result['archive']).read_bytes()).hexdigest(),result['sha256'])
        manifest=json.loads((self.root/'MANIFEST.json').read_text(encoding='utf-8'))
        with zipfile.ZipFile(result['archive']) as z:
            self.assertEqual(json.loads(z.read('cross-view-offline/MANIFEST.json')),manifest)
            for item in manifest['files']:
                value=z.read('cross-view-offline/'+item['path'])
                self.assertEqual(hashlib.sha256(value).hexdigest(),item['sha256'])

    def test_tampered_payload_rejected(self):
        result=build_archive(self.root)
        bad=self.root/'work/tampered.zip'
        with zipfile.ZipFile(result['archive']) as source,zipfile.ZipFile(bad,'w') as target:
            for name in source.namelist():target.writestr(name,b'changed' if name.endswith('result.json') else source.read(name))
        with self.assertRaisesRegex(ValueError,'checksum mismatch'):verify_archive(bad)

    def test_unlisted_payload_rejected(self):
        result=build_archive(self.root)
        with zipfile.ZipFile(result['archive'],'a') as z:z.writestr('cross-view-offline/extra.json','{}')
        with self.assertRaisesRegex(ValueError,'inventory mismatch'):verify_archive(result['archive'])

    def test_duplicate_archive_member_rejected(self):
        import warnings
        result=build_archive(self.root)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(result['archive'],'a') as z:z.writestr('cross-view-offline/result.json','{}')
        with self.assertRaisesRegex(ValueError,'duplicate archive member'):verify_archive(result['archive'])

    def test_manifest_excludes_its_own_hash_and_outer_zip(self):
        build_archive(self.root)
        manifest=create_manifest(self.root)
        self.assertNotIn('MANIFEST.json',{f['path'] for f in manifest['files']})
        self.assertNotIn('cross-view-offline.zip',{f['path'] for f in manifest['files']})

if __name__=='__main__':unittest.main(verbosity=2)
