"""Compare a documented target pixel with offline projections; never select a target.

A pixel-distance ranking is conditional on an image association and a camera
hypothesis. It is neither a correspondence decision nor a calibration residual.
"""
import math
import numpy as np


def compare_target_hint(report, hint):
    pixel=np.asarray(hint['head_pixel'],dtype=float)
    size=np.asarray(hint['image_size'],dtype=float)
    if pixel.shape!=(2,) or not np.isfinite(pixel).all():
        raise ValueError('target pixel must be two finite numbers')
    if size.shape!=(2,) or not np.isfinite(size).all() or np.any(size<=0) or np.any(size!=np.floor(size)):
        raise ValueError('invalid target image dimensions')
    if list(size)!=report['model_evidence']['jpeg_size']:
        raise ValueError('target hint image dimensions mismatch; no automatic rescaling')
    if np.any(pixel<0) or np.any(pixel>=size):
        raise ValueError('target hint outside image')
    uncertainty=hint.get('pixel_uncertainty_px')
    if uncertainty is not None and (not isinstance(uncertainty,(int,float)) or isinstance(uncertainty,bool) or not math.isfinite(uncertainty) or uncertainty<0):
        raise ValueError('invalid target pixel uncertainty')
    digest=report['provenance']['jpeg_sha256']
    bound=(hint.get('image_binding_confirmed') is True and hint.get('reference_image_sha256')==digest)
    blockers=list(report['blockers'])
    for blocker in ['TARGET_IDENTITY_UNCONFIRMED','NO_VERIFIED_CROSS_VIEW_CORRESPONDENCE']:
        if blocker not in blockers:blockers.append(blocker)
    if not bound:blockers.append('TARGET_IMAGE_BINDING_UNVERIFIED')
    current=(report.get('capture_current') is True and hint.get('capture_current') is True)
    if not current:blockers.append('CAPTURE_NOT_CURRENT')
    if uncertainty is None:blockers.append('TARGET_PIXEL_UNCERTAINTY_UNSPECIFIED')
    comparisons={}
    for hypothesis in report['hypotheses']:
        rows=[];excluded=[]
        for c in report['candidates']:
            p=c['projections'].get(hypothesis['id'])
            if not p or not p.get('positive_depth') or not p.get('inside_image') or p.get('head_pixel') is None:
                excluded.append(c['candidate_id']);continue
            uv=np.asarray(p['head_pixel'],dtype=float)
            if uv.shape!=(2,) or not np.isfinite(uv).all():
                raise ValueError('nonfinite or malformed candidate pixel')
            rows.append({'candidate_id':c['candidate_id'],'head_pixel':uv.tolist(),
                         'distance_to_hint_px':float(np.linalg.norm(uv-pixel))})
        rows.sort(key=lambda row:(row['distance_to_hint_px'],row['candidate_id']))
        comparisons[hypothesis['id']]={
            'ranking_for_review_only':rows,'excluded_candidate_ids':excluded,
            'nearest_candidate_id_for_review_only':rows[0]['candidate_id'] if rows else None,
            'nearest_distance_px':rows[0]['distance_to_hint_px'] if rows else None,
            'second_nearest_candidate_id_for_review_only':rows[1]['candidate_id'] if len(rows)>1 else None,
            'nearest_margin_px':rows[1]['distance_to_hint_px']-rows[0]['distance_to_hint_px'] if len(rows)>1 else None}
    return {'schema_version':1,'status':'conditional_pixel_comparison_only',
            'target_hint':hint,'image_binding_confirmed':bound,
            'capture_current':current,
            'identity_confirmed':False,'executable':False,'selected_candidate_id':None,
            'blockers':blockers,'hypothesis_comparisons':comparisons,
            'distance_interpretation':'Distance to an approximate handoff pixel under an unverified camera hypothesis; not a measured calibration residual, confidence score, correspondence or target assignment.',
            'next_input':'只需现有首测目标补充包中的标注图、target-selection.json及其原图关联记录；不要求重复健康检查或重采同样数据。',
            'model_investigation':{'local_sdk_source_available':False,
                'repository_audit':report.get('source_discovery'),
                'finding':'现有输入未提供实际部署SDK的图像/标定源码；仓库目录检查不证明本地未推送交付不存在。',
                'minimum_model_input':'实际部署SDK版本及相机发布链相关源码或配置，可离线核查JPEG、K/D/P与外参光学系的关联。'}}
