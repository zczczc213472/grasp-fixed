"""Build and verify one self-contained offline delivery. Never packages hosting state."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

EXCLUDED_DIRS = {'download-site', 'work', '__pycache__', '.git', '.venv', 'node_modules'}
EXCLUDED_NAMES = {'MANIFEST.json', 'cross-view-offline.zip'}
ALLOWED_SUFFIXES = {'.py', '.json', '.md', '.html', '.jpg', '.png', '.txt', '.log', '.cmd'}


def delivery_files(root):
    root=Path(root).resolve()
    selected=[]
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if any(part in EXCLUDED_DIRS or part.startswith('.') for part in rel.parts):
            continue
        if path.is_symlink():
            continue
        if path.is_file() and path.name not in EXCLUDED_NAMES and path.suffix.lower() in ALLOWED_SUFFIXES:
            selected.append(path)
    return selected


def create_manifest(root):
    root=Path(root).resolve()
    return {'schema_version':1,'package_root':'cross-view-offline',
            'identity_confirmed':False,'executable':False,
            'hash_algorithm':'sha256','manifest_self_hash_included':False,
            'files':[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,
                      'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in delivery_files(root)]}


def verify_archive(archive):
    with zipfile.ZipFile(archive) as z:
        names=z.namelist()
        if len(names)!=len(set(names)):
            raise ValueError('duplicate archive member')
        if any(not n.startswith('cross-view-offline/') or '..' in PurePosixPath(n).parts for n in names):
            raise ValueError('invalid archive path')
        manifest=json.loads(z.read('cross-view-offline/MANIFEST.json').decode('utf-8'))
        if manifest.get('identity_confirmed') is not False or manifest.get('executable') is not False:
            raise ValueError('invalid offline manifest status')
        expected={'cross-view-offline/'+f['path'] for f in manifest['files']}|{'cross-view-offline/MANIFEST.json'}
        if set(names)!=expected:
            raise ValueError('manifest inventory mismatch')
        for f in manifest['files']:
            value=z.read('cross-view-offline/'+f['path'])
            if len(value)!=f['bytes'] or hashlib.sha256(value).hexdigest()!=f['sha256']:
                raise ValueError('content checksum mismatch: '+f['path'])
        if z.testzip() is not None:
            raise ValueError('ZIP integrity failure')
    return {'file_count':len(names),'verified':True}


def build_archive(root):
    root=Path(root).resolve()
    manifest=create_manifest(root)
    manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    target=root/'cross-view-offline.zip';temporary=root/'work/delivery.zip.tmp'
    temporary.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.writestr('cross-view-offline/MANIFEST.json',manifest_bytes)
        for f in manifest['files']:
            z.write(root/f['path'],'cross-view-offline/'+f['path'])
    verified=verify_archive(temporary)
    (root/'MANIFEST.json').write_bytes(manifest_bytes)
    temporary.replace(target)
    return dict(verified,archive=str(target),bytes=target.stat().st_size,
                sha256=hashlib.sha256(target.read_bytes()).hexdigest())

if __name__=='__main__':
    print(json.dumps(build_archive(Path(__file__).resolve().parent),indent=2))
