"""Optional offline browser smoke check. Requires Playwright and local Chromium."""
import json
import shutil
import http.server
import threading
from functools import partial
from urllib.parse import urlparse
from pathlib import Path
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parent
class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(root)))
threading.Thread(target=server.serve_forever,daemon=True).start()
origin=f'http://127.0.0.1:{server.server_port}'
with sync_playwright() as p:
    executable=shutil.which('chromium') or shutil.which('google-chrome')
    browser=p.chromium.launch(headless=True,executable_path=executable,args=['--disable-dev-shm-usage','--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
    errors=[];requests=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:requests.append(r.url))
    page.goto(origin+'/review.html',wait_until='load')
    page.wait_for_function('document.querySelector("#status").textContent.includes("35/35")')
    assert page.locator('#rows tr').count()==35
    assert '56.4 px' in page.locator('#target-summary').inner_text()
    assert page.locator('#candidate').input_value()=='all'
    page.uncheck('#show-target')
    assert not page.locator('#show-target').is_checked()
    page.check('#show-target')
    assert not page.locator('#error').inner_text()
    assert page.evaluate('document.querySelector("#photo").toDataURL().length > 100000')
    page.locator('#depth-view summary').click()
    page.wait_for_function('document.querySelector("#depth-image").naturalWidth === 1280')
    page.locator('#depth-view summary').click()
    page.screenshot(path=str(root/'review-preview.png'),full_page=True)
    page.select_option('#hypothesis','H1')
    assert 'H1' in page.locator('#status').inner_text()
    assert '59.6 px' in page.locator('#target-summary').inner_text()
    assert page.locator('#candidate').input_value()=='all'
    page.select_option('#candidate','19')
    assert '缺失，未填补' in page.locator('#details').inner_text()
    page.uncheck('#labels')
    page.locator('#opacity').fill('45')
    page.click('#reset')
    assert page.locator('#candidate').input_value()=='all'
    assert page.locator('#hypothesis').input_value()=='H0'
    assert page.locator('#labels').is_checked()
    assert page.locator('#show-target').is_checked()
    page.set_viewport_size({'width':390,'height':844})
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    page.evaluate('report.candidates=[]; report.candidate_count=0; report.projection_diagnostics.H0_to_H1_pixel_shift_min_median_max=null; draw()')
    assert page.locator('#rows tr').count()==0
    assert errors==[],errors
    assert all(u.startswith(origin+'/') or u.startswith('data:') for u in requests),requests
    result={'result':'PASS','mode':'loopback HTTP; internet resources forbidden', 'file_url_limitation':'managed Chromium returned ERR_BLOCKED_BY_ADMINISTRATOR for file://; HTML has no fetch/module dependency and uses only relative JPEG/PNG images','browser':'Chromium',
            'checks':['depth preview load','empty candidate UI','target hint overlay toggle','H0/H1 target distance','no automatic target selection','35 rows','image loaded','H0/H1 switch','candidate 19 missing depth','label toggle','opacity','reset','390px mobile width','no JS errors','no external network requests'],
            'page_errors':errors,'remote_request_count':sum(not (u.startswith(origin+'/') or u.startswith('data:')) for u in requests),
            'relative_local_resources':[Path(urlparse(u).path).name for u in requests if u.startswith(origin+'/')]}
    (root/'browser-test-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    browser.close()

server.shutdown()
server.server_close()
