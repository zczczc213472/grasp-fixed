"""Offline-only cross-view geometry. No robot/SDK/network imports or motion outputs.

Camera points use optical axes (+X right, +Y down, +Z forward); poses are
camera->base [tx,ty,tz,qx,qy,qz,qw], metres. Models must be explicit.
Requires NumPy and Pillow. Run this file to regenerate JSON and embedded HTML.
"""
from __future__ import annotations
import base64
import hashlib
import io
import json
from pathlib import Path
import zlib
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent


def finite_array(value, shape=None):
    a = np.asarray(value, dtype=float)
    if (shape is not None and a.shape != shape) or not np.all(np.isfinite(a)):
        raise ValueError('invalid shape or nonfinite numeric data')
    return a


def quaternion_rotation(xyzw):
    q = finite_array(xyzw, (4,))
    scale = np.max(np.abs(q))
    if scale == 0:
        raise ValueError('zero quaternion')
    q = q / scale
    q = q / np.linalg.norm(q)
    x, y, z, w = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def transform_points(points, camera_to_base_xyzw, inverse=False):
    p = finite_array(points)
    if p.ndim < 1 or p.shape[-1] != 3:
        raise ValueError('points must end in XYZ')
    pose = finite_array(camera_to_base_xyzw, (7,))
    r = quaternion_rotation(pose[3:])
    return (p-pose[:3]) @ r if inverse else p @ r.T + pose[:3]


def validate_camera(model, K, D, image_size, calibration_size):
    if model not in ('pinhole', 'plumb_bob', 'equidistant'):
        raise ValueError('unknown model; explicit model required')
    for dimensions in (image_size, calibration_size):
        if len(dimensions) != 2 or any(isinstance(v, (bool, np.bool_)) or not np.isfinite(v) or int(v) != v or v <= 0 for v in dimensions):
            raise ValueError('invalid image dimensions')
    if tuple(image_size) != tuple(calibration_size):
        raise ValueError('image size does not match calibration; no automatic rescaling')
    k = finite_array(K).reshape(3, 3)
    if k[0, 0] <= 0 or k[1, 1] <= 0 or not np.allclose(k[2], [0, 0, 1]) or k[1, 0] != 0:
        raise ValueError('invalid camera matrix')
    d = finite_array(D)
    if d.ndim != 1 or (model == 'pinhole' and d.size != 0) or (model == 'plumb_bob' and d.size != 5) or (model == 'equidistant' and d.size != 4):
        raise ValueError('model/coefficient mismatch')
    return k, d


def project_points(points, K, *, model, D, image_size, calibration_size):
    """Return pixels, positive-depth validity, in-image mask. Invalid pixels are NaN.

    Equidistant requires caller-provided k1..k4; camera_type never selects it.
    Out-of-image points retain coordinates for diagnosis, but are marked outside.
    """
    k, d = validate_camera(model, K, D, image_size, calibration_size)
    p = finite_array(points)
    if p.ndim < 1 or p.shape[-1] != 3:
        raise ValueError('points must end in XYZ')
    valid = p[..., 2] > 0
    xy = np.divide(p[..., :2], p[..., 2, None], out=np.zeros_like(p[..., :2]), where=valid[..., None])
    x, y = xy[..., 0], xy[..., 1]
    if model == 'plumb_bob':
        k1, k2, p1, p2, k3 = d
        r2 = x*x + y*y
        radial = 1 + k1*r2 + k2*r2*r2 + k3*r2*r2*r2
        xy = np.stack((x*radial+2*p1*x*y+p2*(r2+2*x*x),
                       y*radial+p1*(r2+2*y*y)+2*p2*x*y), axis=-1)
    elif model == 'equidistant':
        radius = np.sqrt(x*x+y*y)
        theta = np.arctan(radius)
        t2 = theta*theta
        theta_d = theta*(1+d[0]*t2+d[1]*t2**2+d[2]*t2**3+d[3]*t2**4)
        ratio = np.divide(theta_d, radius, out=np.ones_like(radius), where=radius > 0)
        xy = xy*ratio[..., None]
    uv = xy @ k[:2, :2].T + k[:2, 2]
    uv = np.where(valid[..., None], uv, np.nan)
    inside = valid & (uv[..., 0] >= 0) & (uv[..., 0] < image_size[0]) & (uv[..., 1] >= 0) & (uv[..., 1] < image_size[1])
    return uv, valid, inside


def decode_depth(evidence):
    if evidence['encoding'] != 'zlib+base64/uint16le':
        raise ValueError('unsupported depth encoding')
    if isinstance(evidence['depth_scale'], bool):
        raise ValueError('invalid depth_scale')
    scale = float(evidence['depth_scale'])  # required real configuration; no fallback
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError('invalid depth_scale')
    w, h = evidence['w'], evidence['h']
    if isinstance(w, bool) or isinstance(h, bool) or not isinstance(w, int) or not isinstance(h, int) or min(w, h) <= 0:
        raise ValueError('invalid depth dimensions')
    decoder = zlib.decompressobj()
    raw = decoder.decompress(base64.b64decode(evidence['data'], validate=True), w*h*2+1)
    if not decoder.eof or decoder.unused_data or decoder.unconsumed_tail or len(raw) != w*h*2:
        raise ValueError('depth byte count does not match dimensions')
    raw = np.frombuffer(raw, dtype='<u2').reshape(h, w)
    metres = raw.astype(float)/scale
    metres[raw == 0] = np.nan  # missing stays missing, never interpolated
    return raw, metres


def unproject_depth(metres, K, *, model):
    """Only explicit pinhole inverse; no implicit inverse distortion."""
    if model != 'pinhole':
        raise ValueError('depth unprojection requires explicit pinhole assumption')
    z = np.asarray(metres, dtype=float)
    if z.ndim != 2:
        raise ValueError('depth must be HxW')
    k, _ = validate_camera(model, K, [], (z.shape[1], z.shape[0]), (z.shape[1], z.shape[0]))
    v, u = np.indices(z.shape)
    rays = np.stack((u, v, np.ones_like(u)), axis=-1) @ np.linalg.inv(k).T
    return rays*z[..., None]


def cross_view_map(wrist_points, wrist_pose, head_pose, head_K, *, model, D, image_size, calibration_size, rectification=None):
    base = transform_points(wrist_points, wrist_pose)
    head = transform_points(base, head_pose, inverse=True)
    if rectification is not None:
        r = finite_array(rectification, (3, 3))
        if not np.allclose(r @ r.T, np.eye(3), atol=1e-6) or not np.isclose(np.linalg.det(r), 1):
            raise ValueError('invalid rectification rotation')
        head = head @ r.T
    pixels, valid, inside = project_points(head, head_K, model=model, D=D, image_size=image_size, calibration_size=calibration_size)
    return {'base_point': base, 'head_camera_point': head, 'head_pixel': pixels, 'positive_depth': valid, 'inside_image': inside}


def require_executable(candidate):
    """This diagnostic package never authorizes an executable target."""
    if candidate.get('identity_confirmed') is not True:
        raise ValueError('candidate identity unconfirmed')
    raise ValueError('offline geometry cannot authorize motion')


def metadata_evidence(e, image_size):
    h = e['head_reference']; i = h['sdk_intrinsic']
    conflicts = ['交付JPEG与像素射线模型的关联尚未确认']
    if 'fisheye' in str(i.get('camera_type', '')).lower() and i.get('distortion_model') == 'plumb_bob' and i.get('D') == [0.0]*5:
        conflicts.append('camera_type='+str(i['camera_type'])+' 与 plumb_bob/D=0 并存；不能推测交付图像模型')
    if i.get('roi', {}).get('do_rectify') is True:
        conflicts.append('roi.do_rectify=True 不证明交付 JPEG 已经过校正')
    if h.get('rectify_requested') is True:
        conflicts.append('rectify_requested=True 是旧采集字段；get_rgb_data 第三参数为 once')
    rotation = np.asarray(i.get('R', []))
    if rotation.size == 9 and not np.allclose(rotation.reshape(3, 3), np.eye(3)):
        conflicts.append('头部 R 非单位矩阵，外参对应原始还是校正光学坐标系未确认')
    conflicts.append('腕部畸变/深度注册/轴向Z或射线距离契约未确认；本轮仅按显式针孔轴向深度假设诊断')
    declared = i.get('distortion_model')
    coefficients = i.get('D', [])
    expected_lengths = {'plumb_bob': 5, 'equidistant': 4, 'pinhole': 0}
    if declared not in expected_lengths:
        conflicts.append('UNKNOWN_DECLARED_MODEL: ' + str(declared))
    elif not isinstance(coefficients, (list, tuple)) or len(coefficients) != expected_lengths[declared]:
        conflicts.append('MODEL_COEFFICIENT_MISMATCH: declared model and D length disagree')
    size_ok = tuple(image_size) == (i['width'], i['height'])
    if not size_ok:
        conflicts.append('JPEG dimensions mismatch SDK calibration')
    return {'model_determined': False, 'confirmed_model': None,
            'sdk_intrinsic': i, 'jpeg_size': list(image_size), 'image_size_matches': size_ok,
            'legacy_rectify_requested': h.get('rectify_requested'), 'third_rgb_argument': 'once',
            'conflicts': conflicts, 'extrinsic_source': e['extrinsic_source'],
            'wrist_unprojection_assumption': 'pinhole, optical-axis Z=raw/depth_scale; unverified delivery contract',
            'automatic_model_selection': False}


def sample_depth_at_pixel(depth, pixel):
    """Return the nearest existing depth sample; outside/missing remains None."""
    uv = np.asarray(pixel, dtype=float)
    if uv.shape != (2,) or not np.all(np.isfinite(uv)):
        return None
    h, w = depth.shape
    if not (0 <= uv[0] < w and 0 <= uv[1] < h):
        return None
    x, y = np.rint(uv).astype(int)
    if not (0 <= x < w and 0 <= y < h):
        return None
    value = float(depth[y, x])
    return value if np.isfinite(value) and value > 0 else None


def safe_pixel(pixel):
    return [float(x) for x in pixel] if np.all(np.isfinite(pixel)) else None


def build_report(e, a, jpeg_bytes):
    image = Image.open(io.BytesIO(jpeg_bytes)); image.load()
    size = image.size; meta = metadata_evidence(e, size)
    h = e['head_reference']; intr = h['sdk_intrinsic']
    if not meta['image_size_matches']:
        raise ValueError('JPEG dimensions mismatch SDK calibration')
    validate_camera(intr.get('distortion_model'), intr['K'], intr.get('D', []), size, (intr['width'], intr['height']))
    raw_jpeg = base64.b64decode(h['data'], validate=True)
    if raw_jpeg != jpeg_bytes:
        raise ValueError('reference JPEG does not match captured evidence; image binding unverified')
    p_matrix = finite_array(intr['P']).reshape(3, 4)
    if not np.allclose(p_matrix[:, 3], 0, rtol=0, atol=1e-12):
        raise ValueError('nonzero P translation is unsupported by H1; no silent omission')
    rectification = finite_array(intr['R']).reshape(3, 3)
    if not np.allclose(rectification @ rectification.T, np.eye(3), atol=1e-6) or not np.isclose(np.linalg.det(rectification), 1):
        raise ValueError('invalid rectification rotation')
    raw, depth = decode_depth(e)
    cloud_camera = unproject_depth(depth, e['K'], model='pinhole')
    valid = np.isfinite(depth)
    if not np.any(valid):
        raise ValueError('no measured depth; cannot diagnose candidates')
    cloud = transform_points(cloud_camera[valid], e['camera_to_base_xyzw'])
    table = float(a['surface_candidate_z_m'])
    if not np.isfinite(table):
        raise ValueError('nonfinite surface hypothesis')
    valid_flat_indices = np.flatnonzero(valid)
    hypotheses = [
        {'id':'H0', 'label':'SDK声明模型 / K；假设外参已对应交付图像', 'model':intr['distortion_model'], 'D':intr['D'], 'K':intr['K'], 'R':None},
        {'id':'H1', 'label':'SDK R + P；假设外参对应校正前光学系', 'model':'pinhole', 'D':[], 'K':p_matrix[:,:3].ravel().tolist(), 'R':rectification.tolist()}
    ]
    blockers = ['HEAD_IMAGE_MODEL_UNCONFIRMED', 'WRIST_DEPTH_CONTRACT_UNVERIFIED', 'IDENTITY_UNCONFIRMED',
                'SDK_EXTRINSICS_NOT_INDEPENDENTLY_CALIBRATED', 'EXPOSURE_SYNCHRONIZATION_UNPROVEN', 'TABLE_IS_HORIZONTAL_SURFACE_HYPOTHESIS']
    candidates = []
    if a.get('candidate_count', len(a['cube_25mm_candidates'])) != len(a['cube_25mm_candidates']):
        raise ValueError('candidate count does not match original array')
    for idx, c in enumerate(a['cube_25mm_candidates']):
        xy = finite_array(c['center_xy_m'], (2,))
        extent = finite_array(c['observed_extent_m'], (3,)) * 1000
        if np.any(extent < 0):
            raise ValueError('negative observed extent')
        base = finite_array([*xy, c['surface_top_z_m']], (3,))
        wrist = transform_points(base, e['camera_to_base_xyzw'], inverse=True)
        wrist_pixel, _, wrist_in = project_points(wrist, e['K'], model='pinhole', D=[], image_size=(e['w'],e['h']), calibration_size=(e['w'],e['h']))
        projections = {}
        for hyp in hypotheses:
            result = cross_view_map(wrist, e['camera_to_base_xyzw'], h['camera_to_base_xyzw'], hyp['K'], model=hyp['model'], D=hyp['D'], image_size=size, calibration_size=(intr['width'],intr['height']), rectification=hyp['R'])
            projections[hyp['id']] = {'head_pixel':safe_pixel(result['head_pixel']), 'inside_image':bool(result['inside_image']), 'positive_depth':bool(result['positive_depth']), 'head_camera_point':result['head_camera_point'].tolist()}
        nearest_i = int(np.argmin(np.sum((cloud-base)**2, axis=1)))
        nearest = cloud[nearest_i]
        measured = sample_depth_at_pixel(depth, wrist_pixel) if bool(wrist_in) else None
        nearest_flat = int(valid_flat_indices[nearest_i])
        nearest_y, nearest_x = divmod(nearest_flat, e['w'])
        candidates.append({'candidate_id':idx, 'original_candidate':c, 'base_point':base.tolist(),
            'base_point_kind':'input cluster XY centroid + top Z statistic, not a measured XYZ sample or grasp center',
            'head_pixel':projections['H0']['head_pixel'], 'head_pixel_hypothesis':'H0; uncalibrated', 'projections':projections,
            'wrist_pixel':safe_pixel(wrist_pixel), 'wrist_center_depth_m':measured,
            'nearest_measured_base_point':nearest.tolist(),
            'nearest_measured_wrist_pixel':[nearest_x, nearest_y], 'nearest_measured_raw_depth':int(raw[nearest_y, nearest_x]), 'nearest_measured_distance_mm':float(np.linalg.norm(nearest-base)*1000),
            'height_above_surface_mm':float((base[2]-table)*1000), 'height_minus_25mm':float((base[2]-table)*1000-25),
            'observed_extent_mm':extent.tolist(), 'observed_extent_minus_25mm':(extent-25).tolist(),
            'metrics_note':'observed axis-aligned partial-cluster spans, not complete cube dimensions; surface is assumed horizontal',
            'identity_confirmed':False, 'executable':False, 'blockers':blockers})
    delta = [float(np.linalg.norm(np.asarray(c['projections']['H0']['head_pixel'])-c['projections']['H1']['head_pixel'])) for c in candidates]
    report = {'schema_version':1, 'identity_confirmed':False, 'executable':False, 'capture_current':False, 'robot_actions_executed':False,
            'coordinate_frame':'base_link', 'units':{'base_point':'m','head_pixel':'pixel','diagnostic_sizes':'mm'},
            'model_evidence':meta, 'blockers':blockers, 'hypotheses':hypotheses,
            'provenance':{'depth_scale':float(e['depth_scale']), 'depth_encoding':e['encoding'],
                'jpeg_matches_embedded_bytes':raw_jpeg==jpeg_bytes,
                'jpeg_sha256':hashlib.sha256(jpeg_bytes).hexdigest(),
                'captured_at_robot':e['captured_at_robot'], 'head_received_at_robot':h['received_at_robot'],
                'receive_gap_s':h['received_at_robot']-e['captured_at_robot'], 'max_joint_drift_rad':e['max_joint_drift_rad'],
                'time_note':'receive gap is not exposure synchronization evidence',
                'quaternion_norms_before_normalization':{'wrist':float(np.linalg.norm(e['camera_to_base_xyzw'][3:])), 'head':float(np.linalg.norm(h['camera_to_base_xyzw'][3:]))}},
            'depth_diagnostics':{'width':e['w'],'height':e['h'],'total_pixels':int(raw.size), 'valid_pixels':int(valid.sum()),
                'missing_pixels':int((~valid).sum()), 'valid_fraction':float(valid.mean()),
                'valid_depth_m_min_median_max':[float(np.min(depth[valid])),float(np.median(depth[valid])),float(np.max(depth[valid]))],
                'missing_depth_policy':'zero stays missing; no infill or synthetic measurements',
                'table_hypothesis_z_m':table, 'measured_points_within_5mm_of_horizontal_table':int((np.abs(cloud[:,2]-table)<=.005).sum()),
                'table_note':'local conditional support only; not independently measured plane calibration'},
            'projection_diagnostics':{'H0_to_H1_pixel_shift_min_median_max':([float(min(delta)),float(np.median(delta)),float(max(delta))] if delta else None),
                'measured_reprojection_error_px':None, 'matched_control_points':0,
                'apparent_misalignment_observed':True if candidates else None, 'systematic_calibration_bias_confirmed':False,
                'visual_review':[
                    {'candidate_id':0, 'observation':'H0 (845.6,360.3) lies near right gripper; not a confirmed cube correspondence'},
                    {'candidate_id':2, 'observation':'H0 (748.1,632.0) lies on apparently empty tabletop; no visible 25mm cube centered there'},
                    {'candidate_id':27, 'observation':'H0 (584.3,573.6) is left of the white block assembly in the JPEG; no verified association'},
                    {'note':'manual qualitative review of delivered JPEG; not annotated ground-truth correspondences or measured residuals'}],
                'interpretation':'hypothesis sensitivity only; no verified cross-camera correspondences, so no calibration residual or identity claim'},
            'minimum_missing_information':{'single_request':'请提供这一帧头部 JPEG 的权威像素→光学射线交付契约：它是原图还是经何种校正/裁剪/缩放输出、对应的模型及有效 K/D（校正图为有效 P），以及 SDK 外参对应校正前还是校正后的光学系。只需该帧的关联说明或等价查表，不重采整套数据。',
                'scope':'this resolves head-model ambiguity only; it does not confirm object identity, wrist depth contract, independent calibration or motion readiness'},
            'candidate_count':len(candidates), 'candidates':candidates}
    reviewed_pixels = {0: [845.6235767368354, 360.2755488125303],
                       2: [748.1122098436422, 631.9991496705474],
                       27: [584.343565791847, 573.6413553374152]}
    manual_review_applies = hashlib.sha256(jpeg_bytes).hexdigest() == 'c5948f4f4acd3c90607bd42332d9b2443b2c6c50ade47763cc685a798249b407' and all(idx < len(candidates) and candidates[idx]['head_pixel'] is not None
                               and np.allclose(candidates[idx]['head_pixel'], uv, atol=1e-7, rtol=0)
                               for idx, uv in reviewed_pixels.items())
    if not manual_review_applies:
        report['projection_diagnostics']['visual_review'] = []
        report['projection_diagnostics']['apparent_misalignment_observed'] = None
    return report


def depth_preview_png(depth, near_m=0.1, far_m=1.0):
    """A numeric depth visualization; missing pixels remain exactly black."""
    if not np.isfinite([near_m, far_m]).all() or far_m <= near_m:
        raise ValueError('invalid display depth range')
    valid = np.isfinite(depth) & (depth > 0)
    c = np.zeros_like(depth, dtype=float)
    c[valid] = np.clip((depth[valid]-near_m)/(far_m-near_m), 0, 1)
    rgb = np.zeros((*depth.shape, 3), dtype=np.uint8)
    rgb[valid, 0] = np.rint(255*c[valid]).astype(np.uint8)
    rgb[valid, 1] = np.rint(255*(1-c[valid])).astype(np.uint8)
    rgb[valid, 2] = 80
    buffer = io.BytesIO()
    Image.fromarray(rgb).save(buffer, format='PNG')
    return buffer.getvalue()


def main():
    epath = ROOT/'inputs/right-scene-evidence.local.json'
    apath = ROOT/'inputs/right-scene-analysis.local.json'
    e = json.loads(epath.read_text(encoding='utf-8')); a = json.loads(apath.read_text(encoding='utf-8'))
    report = build_report(e, a, (ROOT/'right-head-reference.local.jpg').read_bytes())
    report['provenance']['source_sha256'] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (epath,apath)}
    _, measured_depth = decode_depth(e)
    outputs = [(ROOT/'depth-preview.png', depth_preview_png(measured_depth))]
    report['depth_diagnostics']['preview'] = {'file':'depth-preview.png','display_range_m':[0.1,1.0], 'outside_display_range':'saturated colors, original values unchanged', 'missing':'exactly black; no fill'}
    audit_path = ROOT/'inputs/source-discovery.json'
    if audit_path.exists():
        report['source_discovery'] = json.loads(audit_path.read_text(encoding='utf-8'))
        report['provenance']['source_sha256'][audit_path.name] = hashlib.sha256(audit_path.read_bytes()).hexdigest()
    hint_path = ROOT/'inputs/target-hint.from-handoff.json'
    if hint_path.exists():
        from target_cross_view import compare_target_hint
        hint = json.loads(hint_path.read_text(encoding='utf-8'))
        target_report = compare_target_hint(report, hint)
        outputs.append((ROOT/'target-report.json', json.dumps(target_report, ensure_ascii=False, indent=2, allow_nan=False)+'\n'))
        report['target_diagnostics'] = target_report
        report['provenance']['source_sha256'][hint_path.name] = hashlib.sha256(hint_path.read_bytes()).hexdigest()
    report_text = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n'
    template = (ROOT/'review-template.html').read_text(encoding='utf-8')
    html = template.replace('__REPORT_JSON__', json.dumps(report, ensure_ascii=False, allow_nan=False).replace('</','<\\/'))
    outputs.extend([(ROOT/'projection-report.json', report_text), (ROOT/'review.html', html)])
    # Validate all inputs and serialization before replacing any generated output.
    for path, value in outputs:
        temporary = path.with_name(path.name+'.tmp')
        if isinstance(value, bytes):
            temporary.write_bytes(value)
        else:
            temporary.write_text(value, encoding='utf-8')
        temporary.replace(path)
    print(json.dumps({'candidates':report['candidate_count'], 'depth':report['depth_diagnostics'], 'projection':report['projection_diagnostics']},ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
