"""Target comparison rejects unsupported associations and never assigns identity."""
import copy
import json
from pathlib import Path
import unittest
import numpy as np
from target_cross_view import compare_target_hint


def fixture():
    report={'blockers':['HEAD_IMAGE_MODEL_UNCONFIRMED'],'model_evidence':{'jpeg_size':[100,80]},
            'provenance':{'jpeg_sha256':'test-reference-digest'},'hypotheses':[{'id':'H0'}],
            'candidates':[{'candidate_id':8,'projections':{'H0':{'head_pixel':[53,44],'positive_depth':True,'inside_image':True}}},
                          {'candidate_id':0,'projections':{'H0':{'head_pixel':[80,40],'positive_depth':True,'inside_image':True}}}]}
    hint={'head_pixel':[50,40],'image_size':[100,80],'pixel_is_approximate':True,
          'image_binding_confirmed':False,'capture_current':False}
    return report,hint


class TargetComparisonTests(unittest.TestCase):
    def test_known_pixel_distance_without_assignment(self):
        r,h=fixture();out=compare_target_hint(r,h);rows=out['hypothesis_comparisons']['H0']['ranking_for_review_only']
        self.assertEqual(rows[0]['candidate_id'],8);self.assertAlmostEqual(rows[0]['distance_to_hint_px'],5)
        self.assertAlmostEqual(out['hypothesis_comparisons']['H0']['nearest_margin_px'],25)
        self.assertIsNone(out['selected_candidate_id']);self.assertIs(out['identity_confirmed'],False)
        self.assertIs(out['executable'],False)

    def test_nearest_at_zero_distance_is_still_unconfirmed(self):
        r,h=fixture();h['head_pixel']=[53,44];h['identity_confirmed']=True;h['executable']=True
        out=compare_target_hint(r,h)
        self.assertEqual(out['hypothesis_comparisons']['H0']['nearest_distance_px'],0)
        self.assertIsNone(out['selected_candidate_id']);self.assertFalse(out['identity_confirmed']);self.assertFalse(out['executable'])

    def test_array_zero_not_chosen_by_default(self):
        r,h=fixture();out=compare_target_hint(r,h)
        self.assertEqual(out['hypothesis_comparisons']['H0']['nearest_candidate_id_for_review_only'],8)

    def test_no_input_mutation(self):
        r,h=fixture();before=copy.deepcopy((r,h));compare_target_hint(r,h);self.assertEqual((r,h),before)

    def test_unverified_image_association_blocks(self):
        r,h=fixture();h['image_binding_confirmed']=True
        out=compare_target_hint(r,h);self.assertFalse(out['image_binding_confirmed'])
        self.assertIn('TARGET_IMAGE_BINDING_UNVERIFIED',out['blockers'])

    def test_bound_reference_does_not_confirm_model_or_identity(self):
        r,h=fixture();h.update(image_binding_confirmed=True,reference_image_sha256='test-reference-digest')
        out=compare_target_hint(r,h);self.assertTrue(out['image_binding_confirmed'])
        self.assertIn('HEAD_IMAGE_MODEL_UNCONFIRMED',out['blockers'])
        self.assertFalse(out['identity_confirmed']);self.assertFalse(out['executable'])

    def test_hint_cannot_promote_old_capture_to_current(self):
        r,h=fixture();h['capture_current']=True
        out=compare_target_hint(r,h);self.assertFalse(out['capture_current']);self.assertIn('CAPTURE_NOT_CURRENT',out['blockers'])

    def test_image_size_mismatch_rejected(self):
        r,h=fixture();h['image_size']=[50,40]
        with self.assertRaisesRegex(ValueError,'dimensions mismatch'):compare_target_hint(r,h)

    def test_nonfinite_and_outside_target_rejected(self):
        for pixel in ([float('nan'),40],[50,float('inf')],[-1,40],[100,40],[50,80],[50]):
            r,h=fixture();h['head_pixel']=pixel
            with self.subTest(pixel=pixel),self.assertRaises(ValueError):compare_target_hint(r,h)

    def test_unknown_uncertainty_is_not_an_acceptance_gate(self):
        r,h=fixture();out=compare_target_hint(r,h)
        self.assertIn('TARGET_PIXEL_UNCERTAINTY_UNSPECIFIED',out['blockers'])
        self.assertFalse(out['identity_confirmed'])
        for uncertainty in (-1,float('nan'),float('inf'),True,'1'):
            h['pixel_uncertainty_px']=uncertainty
            with self.subTest(uncertainty=uncertainty),self.assertRaises(ValueError):compare_target_hint(r,h)

    def test_behind_and_outside_candidates_excluded(self):
        r,h=fixture();r['candidates'][0]['projections']['H0']['positive_depth']=False
        r['candidates'][1]['projections']['H0']['inside_image']=False
        out=compare_target_hint(r,h)['hypothesis_comparisons']['H0']
        self.assertEqual(out['excluded_candidate_ids'],[8,0]);self.assertEqual(out['ranking_for_review_only'],[])
        self.assertIsNone(out['nearest_candidate_id_for_review_only']);self.assertIsNone(out['nearest_distance_px'])

    def test_nonfinite_candidate_pixel_rejected(self):
        r,h=fixture();r['candidates'][0]['projections']['H0']['head_pixel']=[float('nan'),40]
        with self.assertRaises(ValueError):compare_target_hint(r,h)

    def test_ties_have_stable_id_order_without_assignment(self):
        r,h=fixture();r['candidates'][1]['projections']['H0']['head_pixel']=[53,44]
        out=compare_target_hint(r,h)
        self.assertEqual([x['candidate_id'] for x in out['hypothesis_comparisons']['H0']['ranking_for_review_only']],[0,8])
        self.assertIsNone(out['selected_candidate_id'])


class RealTargetEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=Path(__file__).resolve().parent
        cls.report=json.loads((cls.root/'projection-report.json').read_text(encoding='utf-8'))
        cls.hint=json.loads((cls.root/'inputs/target-hint.from-handoff.json').read_text(encoding='utf-8'))
        cls.out=compare_target_hint(cls.report,cls.hint)

    def test_real_distances_are_conditional(self):
        for hyp,expected in [('H0',56.38655674265985),('H1',59.596355785486814)]:
            result=self.out['hypothesis_comparisons'][hyp]
            self.assertEqual(result['nearest_candidate_id_for_review_only'],9)
            self.assertAlmostEqual(result['nearest_distance_px'],expected)
            self.assertEqual(len(result['ranking_for_review_only']),35)
            distances=[x['distance_to_hint_px'] for x in result['ranking_for_review_only']]
            self.assertTrue(all(a<=b for a,b in zip(distances,distances[1:])))
        self.assertIsNone(self.out['selected_candidate_id']);self.assertFalse(self.out['identity_confirmed'])

    def test_handoff_provenance_and_missing_annotation_not_fabricated(self):
        import hashlib
        source=self.root/'inputs'/self.hint['source_file']
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),self.hint['source_sha256'])
        self.assertEqual(self.hint['source_kind'],'secondary_handoff_note')
        self.assertEqual(self.hint['head_pixel'],[778,498])
        self.assertFalse(self.out['image_binding_confirmed']);self.assertFalse(self.out['capture_current'])
        self.assertIsNone(self.hint['pixel_uncertainty_px'])

    def test_saved_target_and_embedded_report_reproduce(self):
        saved=json.loads((self.root/'target-report.json').read_text(encoding='utf-8'))
        self.assertEqual(saved,self.out);self.assertEqual(self.report['target_diagnostics'],saved)
        html=(self.root/'review.html').read_text(encoding='utf-8')
        embedded=json.loads(html.split('<script id="report-data" type="application/json">')[1].split('</script>')[0])
        self.assertEqual(embedded['target_diagnostics'],saved)
        json.dumps(saved,allow_nan=False)

if __name__=='__main__':unittest.main(verbosity=2)
