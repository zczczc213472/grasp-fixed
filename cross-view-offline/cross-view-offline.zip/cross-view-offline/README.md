# 跨视图离线开发包 v3

解压整个 `cross-view-offline/`，直接打开 `review.html`。页面和同目录照片、深度预览均无需互联网、Python或机器人。不要单独移动 HTML。

本包完成了现有数据可支持的离线几何、目标粗标比较、实测深度来源追溯、显示、测试与交付验证。**指定目标身份、相机交付模型和当前真机抓取/归位均未确认**。详细完成范围及缺口统一见 `COMPLETION.md`，不把旧采集转为运动目标。

## 一键复算与打包

复算环境需已有 Python 3.8+、NumPy、Pillow。依赖名称见 `requirements.txt`；查看页面不需要这些依赖。

```sh
python -B run_offline.py
```

Windows 可双击 `RUN_OFFLINE.cmd`，或运行：

```powershell
py -3 -X utf8 -B run_offline.py
```

入口会依次重算几何/目标报告和 HTML、生成实测深度预览、运行全部单元测试、在非 UTF-8 默认 locale 下重跑同一组测试、生成 `run-status.json` 与文件哈希清单，最后只生成一个 `cross-view-offline.zip`。任一步失败则不发布新的压缩包，原因写入状态与日志；旧 ZIP 不代表本次通过。

额外验证浏览器（需已安装 Playwright 和本地 Chromium；只启动本机回环服务）：

```sh
python -B run_offline.py --browser
```

没有安装浏览器工具时用默认命令即可；`run-status.json` 会明确记录该次没有运行浏览器检查。此入口不自动安装依赖，不连接机器人，不导入机器人 SDK。

## 文件导航

| 文件 | 用途 |
| --- | --- |
| `COMPLETION.md` | 本次统一完成清单、结果与剩余证据缺口 |
| `review.html` | 离线头图叠加、粗标比较、候选表、原始深度预览 |
| `projection-report.json` / `target-report.json` | 机器可读诊断；身份未确认、不可执行 |
| `cross_view_geometry.py` / `target_cross_view.py` | 纯离线数值实现 |
| `run_offline.py` | 一次运行完整复算、测试及打包 |
| `package_delivery.py` | 完整包生成、逐文件 SHA-256 与 ZIP 验证 |
| `MANIFEST.json` | 每个交付文件的相对路径、大小和 SHA-256；不包含自身哈希 |
| `tests.log` / `encoding-test.log` / `browser-test-results.json` | 实际验证记录 |
| `inputs/` | 原始采集、分析、交接文档、二手粗标及七分支目录检查记录 |
| `REPORT.md` / `TAKEOVER_REPORT.md` | 几何详报与历史 v2 接管记录 |

只校验压缩包内容而不解压或连接网络：

```sh
python -c "from package_delivery import verify_archive; print(verify_archive('cross-view-offline.zip'))"
```

真机 SDK 版本、目标补充图及最新 IK/工具/碰撞交付尚未在本环境提供，包内没有模拟这些文件为已收到的记录。缺口说明已集中在报告中。
