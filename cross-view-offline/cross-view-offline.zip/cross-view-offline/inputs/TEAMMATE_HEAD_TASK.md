# 队友开发任务：头部身份与右腕深度的离线对应

你在另一台电脑工作；本包包含真实采集证据，不需要连接机器人。当前由用户自己的Claude Code开发碰撞适配，你不要改那条线。

## 只修改范围
自己新建 cross-view-offline/，实现 cross_view_geometry.py、test_cross_view_geometry.py、review.html、REPORT.md。不要修改robot_exec.py、grasp_client.py、客户端、collision-offline/。只把这个目录交回。

## 输入
right-scene-evidence.local.json、right-scene-analysis.local.json、right-head-reference.local.jpg。目标方块25×25×25mm；多块颜色相似，不能默认候选0就是目标。
- 深度：uint16 little-endian，经zlib/base64压缩；meters=raw/depth_scale。本轮scale=10000，不要写死1000。
- 腕部K、camera_to_base_xyzw；头部参数在head_reference.sdk_intrinsic与head_reference.camera_to_base_xyzw。
- 外参[tx,ty,tz,qx,qy,qz,qw]；坐标单位米。
- SDK get_rgb_data第三参数True是once，不是校正。旧字段rectify_requested=True不能作为校正证明。
- 头参数标注plumb_bob且D=0，同时camera_type=shitong-fisheye和roi.do_rectify=True，图像与参数的交付匹配关系尚未确认。

## 本轮实现
1. 正向/逆向刚体变换、投影函数；支持明确传入的模型。未知或不匹配元数据要报告，不能凭camera_type自动猜模型。
2. 生成离线HTML：展示头部照片，在上面叠加带编号的右腕候选投影；允许切换诊断假设，明确标记“诊断假设，未完成校准”。可选显示深度/俯视候选。使用相对资源，不依赖网络。
3. 对25mm候选给出尺寸与桌面相对高度等诊断指标，保留原始候选。不将缺深度区域补算为实测，不自动输出运动目标。
4. 输出projection-report.json，包含model_evidence、candidate_id、head_pixel、base_point、identity_confirmed=false、executable=false、blockers。
5. 在REPORT.md写清：图像模型能否由现有证据确定；是否存在明显跨相机投影偏差；不能确定时给出唯一最小缺失信息，不重新要求整套采集。

## 有意义的测试
单位转换（10000）、四元数归一化与零值拒绝、已知旋转平移往返、相机后方点拒绝、未知模型拒绝、图像尺寸不匹配、候选未确认不能成为可执行目标。

不要连接机器人/读密码/调头部或右臂；不要重做先前25条融合场景表。现有数据足够开发显示与诊断，校准结论可以诚实为证据不足。
