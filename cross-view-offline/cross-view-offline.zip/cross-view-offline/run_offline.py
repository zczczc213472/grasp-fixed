"""One command: regenerate evidence diagnostics, run tests, verify one final ZIP.

No robot, SDK, SSH or external network operations. --browser additionally runs
an optional Chromium check using only a temporary loopback HTTP server.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile
from package_delivery import build_archive

ROOT=Path(__file__).resolve().parent


def run_step(label,args,log,env):
    completed=subprocess.run(args,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                             encoding='utf-8',errors='replace',timeout=180)
    (ROOT/log).write_text(completed.stdout,encoding='utf-8')
    if completed.returncode:
        raise RuntimeError(label+' failed; see '+log)
    return completed.stdout


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--browser',action='store_true',help='also run installed Playwright/local Chromium smoke check')
    args=parser.parse_args()
    env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',OPENBLAS_NUM_THREADS='1')
    status={'schema_version':1,'scope':'offline_only','identity_confirmed':False,'executable':False,
            'robot_actions_executed':False,'checks':{},'status':'running'}
    try:
        run_step('diagnostics',[sys.executable,'-B','cross_view_geometry.py'],'geometry-run.log',env)
        status['checks']['diagnostics']='passed'
        log=run_step('unit tests',[sys.executable,'-B','-m','unittest','discover','-s','.','-p','test*.py','-v'],'tests.log',env)
        match=re.search(r'Ran (\d+) tests?',log)
        if not match:raise RuntimeError('unit test count unavailable; see tests.log')
        status['checks']['unit_tests']={'result':'passed','count':int(match.group(1))}
        encoding_env=dict(env,LC_ALL='C',PYTHONUTF8='0',PYTHONCOERCECLOCALE='0')
        run_step('non-UTF8 default locale',[sys.executable,'-B','-m','unittest','discover','-s','.','-p','test*.py','-q'],'encoding-test.log',encoding_env)
        status['checks']['non_utf8_locale']='passed; same tests repeated, not additional tests; not a Windows run'
        if args.browser:
            run_step('browser',[sys.executable,'-B','check_review.py'],'browser-run.log',env)
            status['checks']['browser']=json.loads((ROOT/'browser-test-results.json').read_text(encoding='utf-8'))
        else:
            status['checks']['browser']={'result':'not_run_this_invocation','command':'python run_offline.py --browser'}
        projection=json.loads((ROOT/'projection-report.json').read_text(encoding='utf-8'))
        status['blockers']=projection['blockers']+projection.get('target_diagnostics',{}).get('blockers',[])
        status['blockers']=list(dict.fromkeys(status['blockers']))
        status['status']='offline_checks_passed; identity_and_live_execution_unconfirmed'
        (ROOT/'run-status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        artifact=build_archive(ROOT)
        print(json.dumps({'status':status['status'],'unit_tests':status['checks']['unit_tests'],'delivery':artifact},indent=2))
        return 0
    except (OSError,ValueError,RuntimeError,zipfile.BadZipFile,subprocess.TimeoutExpired) as error:
        status['status']='failed';status['error']=str(error);status['existing_archive_is_current']=False
        (ROOT/'run-status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(str(error),file=sys.stderr)
        return 1

if __name__=='__main__':
    raise SystemExit(main())
