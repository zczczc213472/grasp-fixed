@echo off
setlocal
cd /d "%~dp0"
py -3 -X utf8 -B run_offline.py %*
exit /b %errorlevel%
